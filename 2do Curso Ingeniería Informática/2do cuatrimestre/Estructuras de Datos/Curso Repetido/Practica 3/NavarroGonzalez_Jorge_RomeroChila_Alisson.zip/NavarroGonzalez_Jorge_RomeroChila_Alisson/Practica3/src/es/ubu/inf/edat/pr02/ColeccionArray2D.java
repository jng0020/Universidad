package es.ubu.inf.edat.pr02;

import java.util.AbstractCollection;
import java.util.Iterator;

/**
 * Clase que permite manejar matrices de datos contiguas en memoria como si se tratara de una colección lineal.
 * @author Alisson Romero Chila
 * @author Jorge Navarro González 
 * @param <E> acota el tipo de objetos a manejar
 */
public class ColeccionArray2D<E> extends AbstractCollection<E>{ // TODO: completar la cabecera

	/**
	 * Objeto tipo Array de array para almacenar los valores.
	 */
	protected E[][] array;
	
	/**
	 * Atributo tipo entero.
	 */
	private int filas =0;
	
	/**
	 * Atributo tipo entero.
	 */
	private int columnas=0;
	
	/**
	 * Constructor de la clase.
	 * @param arrayc arrayc a almacenar.
	 */
	public ColeccionArray2D(E[][] arrayc){
		this.array = arrayc;
		this.filas = array.length;
		this.columnas = array[0].length;
	}
	
	/**
	 * Crea un objeto tipo itertor.
	 */
	@Override
	public Iterator<E> iterator() {
		return new Iterator2D();
	}
	
	/**
	 * Devulve el tamaño de la matriz.
	 */
	@Override
	public int size() {
		return ((filas)*(columnas));
	}
	
	/**
	 * Clase interna que implementa iterator y permite acceder a cada elemento de la coleccion de forma secuencial. 
	 *
	 */
	private class Iterator2D implements Iterator<E>{
		protected int contFilas=0, contColumnas=-1;
		
		/**
		 * Indica que todavia hay elemento en la colección. 
		 */
		@Override
		public boolean hasNext() {
			return !(contFilas >= filas-1 && contColumnas >= columnas-1);
				
		}
	
		/**Devuelve el siguiente elemento de la colección.
		 */
		@Override
		public E next() {
			if(contColumnas == (columnas -1)) {
					contFilas++;
					contColumnas=0;
			}else {
				contColumnas++;
			}
			return array[contFilas][contColumnas];
		} 
	
		/**
		 * Elimina el elemento de esa posicion. 
		 */
		@Override
		public void remove() {
			array[contFilas][contColumnas] = null;
		} 
	
} 
	
}
