package es.ubu.lsi.utils;

import static org.junit.Assert.*;

import java.util.List;
import org.junit.Test;
import es.ubu.inf.edat.pr03.ColeccionArray2DUtilidades;
import es.ubu.lsi.utils.GeneradorEnteros;
/**
 * 
 * Clase que realiza de análisis de la complejidad algortimica. De los metodos 
 * que se encuentran en la clase ColeccionArray2DUtilidades
 * 
 * @author Jorge Navarro González
 * @author Alisson Romero Chila
 * @version 1.0
 * 
 */

public class PruebaTest {
	/**
	 * Numero maximo de elementos que se quiere probar a trabajar
	 */ 
	int limiteElementos = 10000;
	
	/**
	 * Numero de elementos en el que se quiere aunmentar el tamaño en cada paso.
	 * Se propone obtener 10 mediciones diferentes por cada experimento
	 */
	int paso = limiteElementos/10;
	
	/**
	 * Lista sobre que trabajar
	 */
	List <Integer> listaTrabajo;
	
	/**
	 * Objeto tipo ColeccionArray2DUtilidades con objetos tipo integer
	 */
	ColeccionArray2DUtilidades<Integer> coleccionInteger;
	
	/**
	 * Metodo que comprueba el tiempo que tarda en encontrar el elemento que mas se repite en la coleccion.
	 * Para ello utilizamos la clase GeneradorEnteros para que nos cree una matriz aleatoria 
	 * y de esta forma poder calcular el tiempo de ejecucion.
	 */
	public void comprobacionMasFrecuentes(){

		double inicio, fin;
		coleccionInteger = new ColeccionArray2DUtilidades<>(GeneradorEnteros.matrizAleatoria(limiteElementos));
		System.out.println("\nTiempos de ejecución para comprobación del método ---- MAS FRECUENTES ----");
		
		for(int i=1; i<limiteElementos; i=i+paso){
			inicio = System.currentTimeMillis();
			boolean dis = coleccionInteger.masFrecuente() != 0;
			fin = System.currentTimeMillis(); 
			assertTrue(dis);	
			System.out.println("Num.Elem,"+i+",tiempo(ms),"+(fin-inicio));

		}
		
	}
	
	/**
	 * Metodo que comprueba el tiempo que tarda en sumar el valor de los hashCode de los elementos de la coleccion.
	 * Para ello utilizamos la clase GeneradorEnteros para que nos cree una matriz aleatoria 
	 * y de esta forma poder calcular el tiempo de ejecucion.
	 */
	public void comprobacionSumaHash() {
		double inicio, fin;
		coleccionInteger = new ColeccionArray2DUtilidades<>(GeneradorEnteros.matrizAleatoria(limiteElementos));
		System.out.println("\nTiempos de ejecución para comprobación del método ---- SUMA HASH ----");
		
		for(int i=1; i<limiteElementos; i=i+paso){
			inicio = System.currentTimeMillis();
			boolean dis = coleccionInteger.sumaHash() != 0;
			fin = System.currentTimeMillis(); 
			
			assertTrue(dis);
			System.out.println("Num.Elem,"+i+",tiempo(ms),"+(fin-inicio));

		}
	}
	
	/**
	 * Metodo que comprueba el tiempo que tarda en calcular la diferencia de los valores hasCode de la coleccion.
	 * Para ello utilizamos la clase GeneradorEnteros para que nos cree una matriz aleatoria 
	 * y de esta forma poder calcular el tiempo de ejecucion.
	 */
	public void comprobacionDiferenciasHash(){

		double inicio, fin;
		coleccionInteger = new ColeccionArray2DUtilidades<>(GeneradorEnteros.matrizAleatoria(limiteElementos));
		System.out.println("\nTiempos de ejecución para comprobación del método ---- DIFERENCIAS HASH ----");
		
		for(int i=1; i<limiteElementos; i=i+paso){
			inicio = System.currentTimeMillis();
			boolean dis = coleccionInteger.diferenciasHash(i) != null;
			fin = System.currentTimeMillis(); 
			
			assertTrue(dis);
			System.out.println("Num.Elem,"+i+",tiempo(ms),"+(fin-inicio));
		}
		
	}
	
	/**
	 * Metodo que comprueba el tiempo que tarda en localizar la posicion del elemento pasado como parametro.
	 * Para ello utilizamos la clase GeneradorEnteros para que nos cree una matriz aleatoria 
	 * y de esta forma poder calcular el tiempo de ejecucion.
	 */
	public void comprobacionBusquedaSecuencial() {
		double inicio,fin;
		coleccionInteger = new ColeccionArray2DUtilidades<>(GeneradorEnteros.matrizAleatoria(limiteElementos));
		System.out.println("\nTiempos de ejecución para comprobación del método ---- BÚSQUEDA SECUENCIAL ----");
		for(int i=1; i<limiteElementos; i=i+paso){
			listaTrabajo = GeneradorEnteros.listaAleatoria(i);	
			inicio = System.currentTimeMillis();
			boolean dis = coleccionInteger.busquedaSecuencial(i) != 0;
			fin = System.currentTimeMillis(); 
			
			assertTrue(dis);
			System.out.println("Num.Elem,"+i+",tiempo(ms),"+(fin-inicio));
		}
	}
	
	/**
	 * Metodo que comprueba el tiempo que tarda en localizar la posicion del elemento pasado como parametro.
	 * Para ello utilizamos la clase GeneradorEnteros para que nos cree una matriz aleatoria 
	 * y de esta forma poder calcular el tiempo de ejecucion.
	 */
	public void comprobacionBusquedaBinaria() {
		double inicio,fin;
		coleccionInteger = new ColeccionArray2DUtilidades<>(GeneradorEnteros.matrizAleatoria(limiteElementos));
		System.out.println("\nTiempos de ejecución para comprobación del método ---- BÚSQUEDA BINARIA ----");
		for(int i=1; i<limiteElementos; i=i+paso){
			listaTrabajo = GeneradorEnteros.listaAleatoria(i);
			inicio = System.currentTimeMillis();
			boolean dis = coleccionInteger.busquedaBinaria(i) != 0;
			fin = System.currentTimeMillis(); 
			
			assertTrue(dis);
			System.out.println("Num.Elem,"+i+",tiempo(ms),"+(fin-inicio));
		}
	}

	/**
	* Se repiten los tests de arriba solamente incrementando el numero de elementos de las listas. 
	* De esta forma, se puede comprobar la progresión del tiempo
	* que se tarda en finalizar cada test en función del tamaño de las estructuras empleadas.
	* 
	* Permite aumentar el tamaño de las observaciones hasta que nos encontramos con una tamaño
	* suficientemente grande como para apreciar claramente la diferencia en tiempo. 
	*/
	@Test 
	public void testIncremental(){
		
		limiteElementos = 10;
		
		while(true){
			
			limiteElementos = limiteElementos * 10;
			paso = limiteElementos/10;
			comprobacionMasFrecuentes();
			comprobacionSumaHash();
			comprobacionDiferenciasHash();
			comprobacionBusquedaSecuencial();
			comprobacionBusquedaBinaria();
		}
		
	}
}
