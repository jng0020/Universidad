package es.ubu.lsi.edat.sesion07.g2;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Clase que permite implementar un diccionario bilingüe para obtener la
 * traducción de palabras entre dos idiomas empleando alguna de las clases que
 * implementan HashMap.
 * 
 * En este caso se implementan funciones más avanzadas sobre la original.
 * 
 * @author bbaruque
 *
 */

public class TraduccionAvanzada {

	/**
	 * Mapas que contendrán las traducciones para realizar luego la consulta.
	 * 
	 * En este caso se pretende separar en dos mapas diferentes: aquellas
	 * palabras solo con una traduccion en un mapa y aquellas otras ambigüas
	 * separadas en otro mapa.
	 */

	Map<String, String> mapa = new HashMap<String, String>();

	/**
	 * Método que permite almacenar las diferentes traducciones dentro del Mapa
	 * creado para ello. Se pasan dos arrays de cadenas (del mismo tamaño),
	 * cada uno contiene en la misma posición la traducción de una palabra en
	 * su correspondiente idioma. Se considera el idioma que se pasa como primer
	 * parámetro el idioma que se va a emplear para consultar (esto es el
	 * idioma nativo del usuario) y el segundo el que se obtendrá como
	 * respuesta.
	 * 
	 * Cada palabra tiene en este caso una o varias traducciones (son ambiguas).
	 * Esto implica que la misma palabra puede aparece más de una vez dentro
	 * del mismo vector, teniendo como traduccion palabras diferentes en el otro
	 * vector. Se deberá almacenar por lo tanto las traducciones en dos mapas
	 * diferentes:
	 * 
	 * 1.- La primera vez que aparezca una palabra, se almacenará en un mapa
	 * cuya clave sea una palabra y cuyo valor sea otra palara que es su
	 * traducción.
	 * 
	 * Ejemplo: M1 = ["key"="clave"] M2 =[]
	 * 
	 * 2.- La segunda (o siguientes veces) que aparezca una palabra, si estaba
	 * en el primer mapa se elimina y se almacena en un segundo mapa cuya clave
	 * será la palabra en ese idioma y su valor será una lista con las
	 * diferentes acepciones de esa palabra.
	 * 
	 * Ejemplo: M1 =[] M2 = ["key"={"clave",llave}]
	 * 
	 * @param idioma1
	 *            Array de cadenas con las palabras en el idioma de consulta
	 * @param idioma2
	 *            Array de cadenas correspondientes en el idioma de respuesta.
	 * @return numero de traducciones disponibles (sin contar con las entradas
	 *         que indican las repeticiones)
	 */

	public int cargaDiccionario(String[] idioma1, String[] idioma2) {
		for (int i = 0, j = 0; i < idioma1.length && j < idioma2.length; ++i, ++j) {
			mapa.put(idioma1[i], idioma2[j]);
		}

		return mapa.size();

	}

	/**
	 * Metodo que devuelve la traduccion directa de la palabra que se le pasa
	 * como parámetro o null en caso de que no exista una unica traduccion a
	 * esa palabra
	 * 
	 * @param buscada:
	 *            palabra a traducir
	 * @return traduccion o null si no existe traduccion directa
	 */
	public String buscaTraduccion(String buscada) {

		if (mapa.containsKey(buscada)) {
			return mapa.get(buscada);
		} else {
			// Hay que contar cuantos valores tiene la misma clave
		}
		return null;

	}

	/**
	 * Metodo que devuelve el listado de traducciones posibles sobre la palabra
	 * que se le pasa como parámetro o la lista vacía en caso de que no exista
	 * ambiguedad en la palabra a traducir.
	 * 
	 * @param buscada
	 *            palabra que se desea traducir
	 * @return Lista de String con las posibles traducciones de esa palabra o la
	 *         lista vacía en caso de que no exista ambiguedad en la coleccion
	 */
	public List<String> buscaAmbiguas(String buscada) {

		// TODO - A completar por el alumno

	}

	/**
	 * Método que permite obtener los sinónimos a una palabra dada. En este
	 * caso, la palabra se consultará en el idioma de respuesta. Se devolverán
	 * todas aquellas otras acepciones que se han encontrado almacenadas junto
	 * con la palabra introducida como parámetro (en idioma de respuesta) como
	 * traducciones posibles a palabras en el idioma de consulta original
	 * (nativo)
	 * 
	 * @param buscada
	 *            palabra de la que se quieren obtener sinónimos (idioma de
	 *            respuesta)
	 * @return sinónimos a la palabra introducida (puede haber más de uno)
	 */
	// public List<String> buscaSinonimos(String buscada){
	//
	// TODO - A completar por el alumno - Si sobra tiempo
	//
	// }

	/**
	 * Metodo que elimina completamente el contenido de todos los diccionarios
	 * creados.
	 */
	public void clear() {

		for (int i = 0; i < mapa.size(); ++i) {
			mapa.remove(i);
		}

	}

}
