package es.ubu.lsi.edat.pr10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

import es.ubu.lsi.edat.datos.Proceso;

/**
 * Clase para la soluciónd el ejercicio planteado en la sesión 11 de
 * prácticas de EDAT. Se pretende simular un sistema sencillo de planificación
 * de procesos empleando el algoritmo de SRPT
 * 
 * @author bbaruque
 *
 */
public class PlanificadorProcesos extends PriorityQueue {

	// TODO - Se necesitará contar con una estructura de datos que permita
	// organizar los procesos a planificar (Lista de Colas de Prioridad)
	// Se contará con una cola para cada uno de los niveles de prioridad de un
	// proceso,
	// de manera que los procesos de la misma prioridad se organizan entre sí
	List<PriorityQueue<Proceso>> colas = new ArrayList<PriorityQueue<Proceso>>();

	/**
	 * Constructor de la clase. Es importante asegurarse de que las colas están
	 * correctamente iniciadas.
	 */
	public PlanificadorProcesos() {

		PriorityQueue<Proceso> colaPrioridadMA = new PriorityQueue<Proceso>();
		PriorityQueue<Proceso> colaPrioridadA = new PriorityQueue<Proceso>();
		PriorityQueue<Proceso> colaPrioridadM = new PriorityQueue<Proceso>();
		PriorityQueue<Proceso> colaPrioridadB = new PriorityQueue<Proceso>();
		PriorityQueue<Proceso> colaPrioridadMB = new PriorityQueue<Proceso>();
		colas.add(colaPrioridadMA);
		colas.add(colaPrioridadA);
		colas.add(colaPrioridadM);
		colas.add(colaPrioridadB);
		colas.add(colaPrioridadMB);

	}

	/**
	 * Metodo que permite insertar nuevos procesos en el planificador. Se debe
	 * asegurar que los procesos se distribuyen en cada cola en funcion de su
	 * prioridad.
	 * 
	 * @param proc
	 *            Proceso a introducir en el planificador
	 * @return numero de procesos incluidos en la misma cola en que se ha
	 *         insertado el proceso actual (el actual incluido)
	 */
	public int insertaEnCola(Proceso proc) {
		switch (proc.getPrioridad()) {
		case MUYALTA:
			colas.get(0).add(proc);
			return colas.get(0).size();
		case ALTA:
			colas.get(1).add(proc);
			return colas.get(1).size();
		case MEDIA:
			colas.get(2).add(proc);
			return colas.get(2).size();
		case BAJA:
			colas.get(3).add(proc);
			return colas.get(3).size();
		case MUYBAJA:
			colas.get(4).add(proc);
			return colas.get(4).size();
		default:
			return 0;
		}
	}

	/**
	 * Metodo que permite simular el paso del tiempo en el sistema completo. Se
	 * facilita un numero de instantes de tiempo a avanzar y se reproducirá ese
	 * avance en cada una de las colas. Se deberán eliminar aquellos procesos
	 * que hayan terminado su trabajo (en orden de menor a mayor tiempo) y
	 * restar el tiempo correspondiente a aquellos que no vayan a terminar en el
	 * periodo asignado.
	 * 
	 * @param tiempo
	 *            numero de instantes de tiempo que transcurren en la
	 *            simulación
	 * @return true en caso de que algún proceso finalice en cualquiera de las
	 *         colas y false en caso contrario
	 */
	public boolean adelantaTiempo(int tiempo) {
		boolean bool = false;
		for (PriorityQueue<Proceso> x : colas) {
			int tiempoResta = tiempo;
			while (tiempoResta > 0 && x.isEmpty() == false) {
				if (x.peek() != null) {
					if (x.peek().getTiempoProceso() < tiempoResta) {
						tiempoResta= tiempoResta - x.peek().getTiempoProceso();
						x.poll();
						bool = true;
					} else {
						x.peek().consumeTiempoProceso(tiempoResta);
						tiempoResta=0;
					}
				}
			}
		}
		return bool;

	}

	/**
	 * Metodo que permite consultar el contenido de cada una de las colas del
	 * sistema.
	 * 
	 * Se deberá devolver el contenido en el mismo orden en el que se haya
	 * planificado procesar los elementos en el momento de la llamada.
	 * 
	 * @param prioridad
	 *            correspondiente a la cola que se quiere acceder
	 * @return lista con los procesos incluidos en esa cola en el orden en que
	 *         se van a procesar
	 */
	public List<Proceso> recuperaProcesosPrioridad(Proceso.Prioridad prioridad) {

		LinkedList<Proceso> link = null;
		switch (prioridad) {
		case MUYALTA:
			link = new LinkedList<Proceso>(colas.get(0));
			break;
		case ALTA:
			link = new LinkedList<Proceso>(colas.get(1));
			break;
		case MEDIA:
			link = new LinkedList<Proceso>(colas.get(2));
			break;
		case BAJA:
			link = new LinkedList<Proceso>(colas.get(3));
			break;
		case MUYBAJA:
			link = new LinkedList<Proceso>(colas.get(4));
			break;
		default:
			return null;
		}
		Collections.sort(link);
		return link;
	}

}
