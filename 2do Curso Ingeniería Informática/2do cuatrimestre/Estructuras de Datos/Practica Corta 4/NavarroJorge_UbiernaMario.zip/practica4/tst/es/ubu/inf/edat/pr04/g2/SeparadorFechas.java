package es.ubu.inf.edat.pr04.g2;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;

/**
 * Clase SeparadorFechas.
 * 
 * @author Mario Ubierna San Mames
 * @author Jorge Navarro Gonzalez
 *
 */
public class SeparadorFechas {
	/**
	 * Metodo que nos devuelve una cola organizada.
	 * 
	 * @param listaFechas
	 *            lista con todas la fechas
	 * @param minSeparacion
	 *            el tiempo de separacion entre fechas
	 * @return solucion
	 */
	public static Deque<List<LocalDateTime>> separaFechas(List<LocalDateTime> listaFechas, Duration minSeparacion) {
		/**
		 * Almacena la separacion de tiempo entre dos fechas.
		 */
		Duration d = null;
		/**
		 * Array para almacenar los eventos.
		 */
		List<LocalDateTime> temp = new ArrayList<LocalDateTime>();
		Iterator<LocalDateTime> iterador = listaFechas.iterator();
		/**
		 * Cola en la que devolvemos los eventos ordenados de mas reciente a
		 * menos.
		 */
		Deque<List<LocalDateTime>> solucion = new ArrayDeque<List<LocalDateTime>>();
		/**
		 * Tiempo uno.
		 */
		LocalDateTime dateTime1 = null;
		/**
		 * Tiempo dos.
		 */
		LocalDateTime dateTime2 = null;
		/**
		 * Variable boolean para saber si estamos en un evento o no.
		 */
		boolean enEvento = false;
		// Mientras haya un objeto de tipo LocalDateTime
		while (iterador.hasNext()) {
			// Almacenamos en dateTime1 el valor de dateTime2
			dateTime1 = dateTime2;
			// Almacenamos en dateTime2 el valor siguiente de la lista
			dateTime2 = iterador.next();
			// Si dateTime1 es igual a null pasamos a la siguiente iteracion
			if (dateTime1 == null) {
				continue;
			}
			// Calculamos la duracion entre dateTime1 y dateTime2
			d = Duration.between(dateTime1, dateTime2);
			// Si es menor o igual que minSeparacion
			if (d.compareTo(minSeparacion) <= 0) {
				// Comprobamos si estamos en el inicio de un evento
				if (enEvento == false) {
					temp.add(dateTime1);
					enEvento = true;
				}
			} else {
				// Comprobamos si estamos dentro de un evento
				if (enEvento == true) {
					temp.add(dateTime1);
					solucion.addFirst(temp);
					enEvento = false;
				}
				temp = new ArrayList<LocalDateTime>();
			}
		}
		// Si se llena la lista de un evento, es porque tenemos la ultima fecha
		if (enEvento == true) {
			temp.add(dateTime2);
			solucion.addFirst(temp);
		}
		return solucion;
	}

}
