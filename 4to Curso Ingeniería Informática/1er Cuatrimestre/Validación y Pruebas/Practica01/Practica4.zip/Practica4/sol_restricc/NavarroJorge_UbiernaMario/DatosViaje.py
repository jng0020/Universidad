

def init():    
    global tiempo
    global punto_inicio
    global punto_fin
    global punto_visita
    tiempo = 0
    punto_inicio = []
    punto_fin = []
    punto_visita = []