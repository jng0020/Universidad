﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LibClases.test
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestConstructor()
        {
            Usuario u = new Usuario("NoMbRe");
        }
    }
}
