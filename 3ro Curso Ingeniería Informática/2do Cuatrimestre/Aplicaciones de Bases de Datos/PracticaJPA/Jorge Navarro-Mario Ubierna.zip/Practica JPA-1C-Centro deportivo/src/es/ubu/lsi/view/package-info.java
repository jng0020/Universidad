/**
 * Testing with JDBC and JPA.
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jes�s Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Ra�l Marticorena</a>
 * @author <a href="mailto:mmabad@ubu.es">Mario Mart�nez</a>
 * @since 1.0
 */
package es.ubu.lsi.view;